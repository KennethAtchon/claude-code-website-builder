import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL('https://www.solidkitchenbath.com'),
  title: "Expert Kitchen and Bathroom Remodeling Contractors in Bothell | Solid Kitchen & Bath",
  description: "Give your Bothell home a fresh new look with trusted kitchen and bathroom remodeling contractors. We handle everything from design to build—on time, on budget, and done right.",
  keywords: "kitchen remodeling, bathroom remodeling, Bothell, King County, Snohomish County, contractors, home renovation",
  openGraph: {
    title: "Expert Kitchen and Bathroom Remodeling Contractors in Bothell",
    description: "Trusted kitchen and bathroom remodeling contractors serving King and Snohomish Counties. Quality craftsmanship, on-time delivery.",
    images: ['/og-image.jpg'],
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}

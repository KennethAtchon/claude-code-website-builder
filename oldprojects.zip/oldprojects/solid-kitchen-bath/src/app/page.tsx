import { ReplicatedHeader } from "@/components/ReplicatedHeader";
import { HeroSection } from "@/components/sections/HeroSection";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { ProcessSection } from "@/components/sections/ProcessSection";
import { ProjectsSection } from "@/components/sections/ProjectsSection";
import { TestimonialsSection } from "@/components/sections/TestimonialsSection";
import { ReplicatedFooter } from "@/components/ReplicatedFooter";

export default function Home() {
  return (
    <div className="min-h-screen">
      <ReplicatedHeader />
      <main>
        <HeroSection />
        <ServicesSection />
        <ProcessSection />
        <ProjectsSection />
        <TestimonialsSection />
      </main>
      <ReplicatedFooter />
    </div>
  );
}
"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navigationItems = [
  {
    label: "Our Services",
    href: "/services",
    submenu: [
      { label: "Kitchen Remodel", href: "/services/kitchen-remodel" },
      { label: "Bath Remodel", href: "/services/bath-remodel" }
    ]
  },
  {
    label: "Our Process",
    href: "/process"
  },
  {
    label: "Projects",
    href: "/projects"
  },
  {
    label: "About",
    href: "/about",
    submenu: [
      { label: "About Us", href: "/about" },
      { label: "Customer Reviews", href: "/reviews" }
    ]
  },
  {
    label: "Blogs",
    href: "/blogs"
  }
];

export function ReplicatedHeader() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null);

  return (
    <header className="w-full bg-white border-b border-gray-200 relative z-50">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <div className="w-[150px] h-12 bg-gray-800 flex items-center justify-center text-white font-bold font-montserrat text-lg">
              SOLID
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navigationItems.map((item) => (
              <div
                key={item.label}
                className="relative group"
                onMouseEnter={() => setOpenSubmenu(item.label)}
                onMouseLeave={() => setOpenSubmenu(null)}
              >
                <Link
                  href={item.href}
                  className="text-gray-800 hover:text-gray-600 font-montserrat text-sm font-medium transition-colors duration-200"
                >
                  {item.label}
                </Link>
                
                {/* Submenu */}
                {item.submenu && (
                  <div className={cn(
                    "absolute top-full left-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 transition-all duration-200",
                    openSubmenu === item.label 
                      ? "opacity-100 visible transform translate-y-0" 
                      : "opacity-0 invisible transform translate-y-2"
                  )}>
                    <div className="py-2">
                      {item.submenu.map((subItem) => (
                        <Link
                          key={subItem.label}
                          href={subItem.href}
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 font-montserrat transition-colors duration-200"
                        >
                          {subItem.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Right side - Phone and CTA */}
          <div className="flex items-center space-x-4">
            {/* Phone Number */}
            <Link 
              href="tel:4255887360"
              className="hidden md:flex items-center space-x-2 text-gray-800 hover:text-gray-600 transition-colors duration-200"
            >
              <Phone className="w-4 h-4" />
              <span className="font-montserrat text-sm font-medium">(425) 588-7360</span>
            </Link>

            {/* CTA Button */}
            <Button 
              asChild
              className="bg-gray-800 hover:bg-gray-700 text-white font-montserrat text-sm font-medium px-4 py-2 lg:px-6 lg:py-3 transition-colors duration-200"
            >
              <Link href="/estimate">Get a Free Estimate</Link>
            </Button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-gray-800 hover:text-gray-600 transition-colors duration-200"
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div className={cn(
          "lg:hidden overflow-hidden transition-all duration-300 ease-in-out",
          isMobileMenuOpen 
            ? "max-h-screen opacity-100" 
            : "max-h-0 opacity-0"
        )}>
          <nav className="py-4 space-y-2">
            {navigationItems.map((item) => (
              <div key={item.label}>
                <Link
                  href={item.href}
                  className="block px-4 py-2 text-gray-800 hover:bg-gray-100 font-montserrat text-sm font-medium transition-colors duration-200"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
                {item.submenu && (
                  <div className="ml-4 space-y-1">
                    {item.submenu.map((subItem) => (
                      <Link
                        key={subItem.label}
                        href={subItem.href}
                        className="block px-4 py-1 text-gray-600 hover:bg-gray-50 font-montserrat text-xs transition-colors duration-200"
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        {subItem.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            
            {/* Mobile Phone */}
            <Link 
              href="tel:4255887360"
              className="flex items-center space-x-2 px-4 py-2 text-gray-800 hover:bg-gray-100 font-montserrat text-sm font-medium transition-colors duration-200"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <Phone className="w-4 h-4" />
              <span>(425) 588-7360</span>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
"use client";
import Link from "next/link";
import { Phone, Mail, MapPin, Star, Facebook, Instagram, Linkedin } from "lucide-react";

const footerSections = [
  {
    title: "Our Services",
    links: [
      { label: "Kitchen Remodeling", href: "/services/kitchen-remodel" },
      { label: "Bathroom Remodeling", href: "/services/bath-remodel" },
      { label: "Design Consultation", href: "/services/design" },
      { label: "Project Management", href: "/services/management" }
    ]
  },
  {
    title: "Company",
    links: [
      { label: "About Us", href: "/about" },
      { label: "Our Process", href: "/process" },
      { label: "Customer Reviews", href: "/reviews" },
      { label: "Blog", href: "/blog" }
    ]
  },
  {
    title: "Resources",
    links: [
      { label: "Project Gallery", href: "/projects" },
      { label: "Design Ideas", href: "/ideas" },
      { label: "Maintenance Tips", href: "/tips" },
      { label: "Warranty Info", href: "/warranty" }
    ]
  }
];

const serviceAreas = [
  "Bothell", "Bellevue", "Kirkland", "Redmond", "Woodinville", 
  "Snohomish", "Mill Creek", "Lynnwood", "Edmonds", "Seattle"
];

export function ReplicatedFooter() {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="max-w-[1200px] mx-auto px-4 md:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="mb-6">
              <div className="w-[150px] h-12 bg-white flex items-center justify-center text-gray-900 font-bold font-montserrat text-lg mb-4">
                SOLID
              </div>
              <p className="text-gray-300 font-open-sans leading-relaxed mb-4">
                Expert kitchen and bathroom remodeling contractors serving King and Snohomish Counties. 
                Quality craftsmanship, on-time delivery, and exceptional customer service.
              </p>
            </div>

            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-gray-400" />
                <Link 
                  href="tel:4255887360"
                  className="text-gray-300 hover:text-white font-open-sans transition-colors duration-200"
                >
                  (425) 588-7360
                </Link>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-gray-400" />
                <Link 
                  href="mailto:info@solidkitchenbath.com"
                  className="text-gray-300 hover:text-white font-open-sans transition-colors duration-200"
                >
                  info@solidkitchenbath.com
                </Link>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-gray-400 mt-1" />
                <div className="text-gray-300 font-open-sans">
                  <p>Serving King & Snohomish Counties</p>
                  <p>Washington State</p>
                </div>
              </div>
            </div>

            {/* Rating */}
            <div className="mt-6 p-4 bg-gray-800 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <span className="text-white font-montserrat font-semibold">5.0</span>
              </div>
              <p className="text-gray-300 text-sm font-open-sans">
                Rated 5/5 based on 99+ customer reviews
              </p>
            </div>
          </div>

          {/* Footer Links */}
          {footerSections.map((section) => (
            <div key={section.title}>
              <h3 className="text-lg font-bold text-white font-montserrat mb-4">
                {section.title}
              </h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-gray-300 hover:text-white font-open-sans transition-colors duration-200"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Service Areas */}
        <div className="mt-12 pt-8 border-t border-gray-700">
          <h3 className="text-lg font-bold text-white font-montserrat mb-4">
            Service Areas
          </h3>
          <div className="flex flex-wrap gap-2">
            {serviceAreas.map((area) => (
              <span
                key={area}
                className="bg-gray-800 text-gray-300 px-3 py-1 rounded-full text-sm font-open-sans"
              >
                {area}
              </span>
            ))}
          </div>
        </div>

        {/* Social Media & CTA */}
        <div className="mt-12 pt-8 border-t border-gray-700">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-6 lg:space-y-0">
            {/* Social Links */}
            <div>
              <h3 className="text-lg font-bold text-white font-montserrat mb-4">
                Follow Us
              </h3>
              <div className="flex space-x-4">
                <Link
                  href="https://facebook.com/solidkitchenbath"
                  className="bg-gray-800 p-3 rounded-full hover:bg-gray-700 transition-colors duration-200"
                  aria-label="Facebook"
                >
                  <Facebook className="w-5 h-5 text-gray-300" />
                </Link>
                <Link
                  href="https://instagram.com/solidkitchenbath"
                  className="bg-gray-800 p-3 rounded-full hover:bg-gray-700 transition-colors duration-200"
                  aria-label="Instagram"
                >
                  <Instagram className="w-5 h-5 text-gray-300" />
                </Link>
                <Link
                  href="https://linkedin.com/company/solidkitchenbath"
                  className="bg-gray-800 p-3 rounded-full hover:bg-gray-700 transition-colors duration-200"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-5 h-5 text-gray-300" />
                </Link>
              </div>
            </div>

            {/* CTA */}
            <div className="text-center lg:text-right">
              <h3 className="text-lg font-bold text-white font-montserrat mb-4">
                Ready to Get Started?
              </h3>
              <Link
                href="/estimate"
                className="inline-block bg-white text-gray-900 font-montserrat font-semibold px-6 py-3 rounded-lg hover:bg-gray-100 transition-colors duration-200"
              >
                Get Your Free Estimate
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-700">
        <div className="max-w-[1200px] mx-auto px-4 md:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="text-gray-400 font-open-sans text-sm">
              © 2025 Solid Kitchen & Bath. All rights reserved.
            </div>
            <div className="flex space-x-6">
              <Link
                href="/privacy"
                className="text-gray-400 hover:text-white font-open-sans text-sm transition-colors duration-200"
              >
                Privacy Policy
              </Link>
              <Link
                href="/terms"
                className="text-gray-400 hover:text-white font-open-sans text-sm transition-colors duration-200"
              >
                Terms of Service
              </Link>
              <Link
                href="/accessibility"
                className="text-gray-400 hover:text-white font-open-sans text-sm transition-colors duration-200"
              >
                Accessibility
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
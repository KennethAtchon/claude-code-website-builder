"use client";
import { motion } from "framer-motion";
import { Star, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Link from "next/link";

const projectTypes = [
  "Kitchen Remodel",
  "Bathroom Remodel", 
  "Full Home Remodel",
  "Other"
];

export function HeroSection() {
  return (
    <section className="relative bg-white py-16 lg:py-24">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column - Content */}
          <div className="space-y-8">
            {/* Star Rating */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex items-center space-x-2"
            >
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="text-gray-600 font-montserrat text-sm">
                Rated 5/5 based on 99 reviews
              </span>
            </motion.div>

            {/* Main Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 font-montserrat leading-tight"
            >
              Expert Kitchen and Bathroom{" "}
              <span className="text-gray-700">Remodeling Contractors</span>{" "}
              in Bothell
            </motion.h1>

            {/* Subheading */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg lg:text-xl text-gray-600 font-open-sans leading-relaxed"
            >
              Give your Bothell home a fresh new look with trusted kitchen and bathroom 
              remodeling contractors. We handle everything from design to build—on time, 
              on budget, and done right.
            </motion.p>

            {/* Tagline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-base text-gray-500 font-montserrat italic"
            >
              Enjoy your life by loving where you live
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4"
            >
              <Button 
                asChild
                size="lg"
                className="bg-gray-900 hover:bg-gray-800 text-white font-montserrat font-semibold px-8 py-4 text-base transition-all duration-300 transform hover:scale-105"
              >
                <Link href="/estimate" className="flex items-center space-x-2">
                  <span>Get a Free Estimate</span>
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </Button>
              
              <Button 
                asChild
                variant="outline"
                size="lg"
                className="border-2 border-gray-900 text-gray-900 hover:bg-gray-900 hover:text-white font-montserrat font-semibold px-8 py-4 text-base transition-all duration-300"
              >
                <Link href="/about">About Us</Link>
              </Button>
            </motion.div>
          </div>

          {/* Right Column - Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Card className="p-8 shadow-xl border-0 bg-white">
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 font-montserrat text-center">
                  Get Started
                </h3>
                
                <p className="text-gray-600 font-open-sans text-center">
                  What type of project are you planning?
                </p>

                <div className="grid grid-cols-1 gap-3">
                  {projectTypes.map((type) => (
                    <button
                      key={type}
                      className="p-4 text-left border-2 border-gray-200 rounded-lg hover:border-gray-900 hover:bg-gray-50 transition-all duration-200 font-montserrat font-medium text-gray-800"
                    >
                      {type}
                    </button>
                  ))}
                </div>

                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Your Name"
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-gray-900 focus:outline-none transition-colors duration-200 font-open-sans"
                  />
                  
                  <input
                    type="email"
                    placeholder="Email Address"
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-gray-900 focus:outline-none transition-colors duration-200 font-open-sans"
                  />
                  
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-gray-900 focus:outline-none transition-colors duration-200 font-open-sans"
                  />
                </div>

                <Button 
                  className="w-full bg-gray-900 hover:bg-gray-800 text-white font-montserrat font-semibold py-4 text-base transition-all duration-300"
                >
                  Get My Free Estimate
                </Button>

                <p className="text-xs text-gray-500 text-center font-open-sans">
                  By submitting this form, you agree to our terms and privacy policy.
                </p>
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Service Areas */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <p className="text-gray-600 font-montserrat">
            <span className="font-semibold">Service Areas:</span> King and Snohomish Counties
          </p>
        </motion.div>
      </div>
    </section>
  );
}
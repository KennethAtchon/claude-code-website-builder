"use client";
import { motion } from "framer-motion";
import { MessageCircle, Hammer, Clock, CheckCircle } from "lucide-react";

const processSteps = [
  {
    step: 1,
    icon: MessageCircle,
    title: "Initial Consultation",
    description: "We start by listening to your goals, understanding your style preferences, and discussing your must-haves for the project.",
    details: [
      "In-home design consultation",
      "Style & preference discussion",
      "Budget planning",
      "Timeline expectations"
    ]
  },
  {
    step: 2,
    icon: Hammer,
    title: "Build Phase",
    description: "Our expert team begins with clean and careful demolition, followed by precise installation using quality materials.",
    details: [
      "Professional demolition",
      "Electrical & plumbing work",
      "Installation & craftsmanship",
      "Quality control checks"
    ]
  },
  {
    step: 3,
    icon: Clock,
    title: "Project Completion",
    description: "Most kitchen projects are completed within 4-6 weeks, with regular updates throughout the process.",
    details: [
      "4-6 week timeline for kitchens",
      "Regular progress updates",
      "Quality finishing work",
      "Clean-up & preparation"
    ]
  },
  {
    step: 4,
    icon: CheckCircle,
    title: "Final Walkthrough",
    description: "We conduct a comprehensive final walkthrough and provide a one-year workmanship warranty for your peace of mind.",
    details: [
      "Detailed final inspection",
      "Client walkthrough",
      "One-year warranty",
      "Ongoing support"
    ]
  }
];

export function ProcessSection() {
  return (
    <section className="py-16 lg:py-24 bg-white">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl xl:text-5xl font-bold text-gray-900 font-montserrat mb-6">
            Our Proven Process
          </h2>
          <p className="text-lg lg:text-xl text-gray-600 font-open-sans max-w-3xl mx-auto leading-relaxed">
            From initial consultation to final walkthrough, we've streamlined our process 
            to ensure your remodeling project runs smoothly from start to finish.
          </p>
        </motion.div>

        {/* Process Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {processSteps.map((step, index) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="relative"
            >
              {/* Step Number */}
              <div className="flex items-center justify-center w-16 h-16 bg-gray-900 text-white rounded-full font-bold text-xl font-montserrat mx-auto mb-6">
                {step.step}
              </div>

              {/* Icon */}
              <div className="flex items-center justify-center w-12 h-12 bg-gray-100 rounded-full mx-auto mb-6">
                <step.icon className="w-6 h-6 text-gray-900" />
              </div>

              {/* Content */}
              <div className="text-center">
                <h3 className="text-xl lg:text-2xl font-bold text-gray-900 font-montserrat mb-4">
                  {step.title}
                </h3>
                
                <p className="text-gray-600 font-open-sans mb-6 leading-relaxed">
                  {step.description}
                </p>

                {/* Details List */}
                <ul className="space-y-2 text-left">
                  {step.details.map((detail) => (
                    <li key={detail} className="flex items-start space-x-2">
                      <div className="w-1.5 h-1.5 bg-gray-900 rounded-full mt-2 flex-shrink-0" />
                      <span className="text-gray-700 font-open-sans text-sm">
                        {detail}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Connector Line (hidden on last item) */}
              {index < processSteps.length - 1 && (
                <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gray-200 -translate-x-8 z-0" />
              )}
            </motion.div>
          ))}
        </div>

        {/* Bottom Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-16 text-center"
        >
          <div className="bg-gray-50 rounded-lg p-8 lg:p-12">
            <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 font-montserrat mb-4">
              Why Our Process Works
            </h3>
            <p className="text-gray-600 font-open-sans mb-8 max-w-3xl mx-auto leading-relaxed">
              Our systematic approach ensures every project is completed on time, on budget, and to your exact specifications. 
              We've refined this process through hundreds of successful remodeling projects across King and Snohomish Counties.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl lg:text-4xl font-bold text-gray-900 font-montserrat mb-2">
                  4-6
                </div>
                <p className="text-gray-600 font-open-sans">
                  Week Average<br />Kitchen Timeline
                </p>
              </div>
              <div>
                <div className="text-3xl lg:text-4xl font-bold text-gray-900 font-montserrat mb-2">
                  1 Year
                </div>
                <p className="text-gray-600 font-open-sans">
                  Workmanship<br />Warranty
                </p>
              </div>
              <div>
                <div className="text-3xl lg:text-4xl font-bold text-gray-900 font-montserrat mb-2">
                  99+
                </div>
                <p className="text-gray-600 font-open-sans">
                  Satisfied<br />Customers
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
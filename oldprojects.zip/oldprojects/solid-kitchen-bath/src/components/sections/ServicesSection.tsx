"use client";
import { motion } from "framer-motion";
import { ArrowRight, ChefHat, Droplets } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Link from "next/link";
import Image from "next/image";

const services = [
  {
    icon: ChefHat,
    title: "Kitchen Remodeling",
    description: "Transform your kitchen with smart design and expert craftsmanship. From cabinet installation to countertops and complete layout redesigns.",
    features: [
      "Custom cabinet installation",
      "Countertop selection & installation", 
      "Layout redesign & optimization",
      "Appliance integration",
      "Lighting & electrical work"
    ],
    image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop&q=80",
    href: "/services/kitchen-remodel"
  },
  {
    icon: Droplets,
    title: "Bathroom Remodeling", 
    description: "Create the perfect blend of modern style and everyday comfort with our comprehensive bathroom renovation services.",
    features: [
      "Shower & tub remodeling",
      "Custom tile work",
      "Fixture upgrades", 
      "Vanity & storage solutions",
      "Accessibility improvements"
    ],
    image: "https://images.unsplash.com/photo-1620626011761-996317b8d101?w=800&h=600&fit=crop&q=80",
    href: "/services/bath-remodel"
  }
];

export function ServicesSection() {
  return (
    <section className="py-16 lg:py-24 bg-gray-50">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl xl:text-5xl font-bold text-gray-900 font-montserrat mb-6">
            Our Remodeling Services
          </h2>
          <p className="text-lg lg:text-xl text-gray-600 font-open-sans max-w-3xl mx-auto leading-relaxed">
            From kitchens to bathrooms, we specialize in transforming your home's most important spaces 
            with quality craftsmanship and attention to detail.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
            >
              <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white">
                {/* Service Image */}
                <div className="relative h-64 lg:h-72">
                  <Image
                    src={service.image}
                    alt={service.title}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute bottom-4 left-4">
                    <div className="p-3 bg-white rounded-full">
                      <service.icon className="w-6 h-6 text-gray-900" />
                    </div>
                  </div>
                </div>

                {/* Service Content */}
                <div className="p-8">
                  <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 font-montserrat mb-4">
                    {service.title}
                  </h3>
                  
                  <p className="text-gray-600 font-open-sans mb-6 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Features List */}
                  <ul className="space-y-2 mb-8">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-gray-900 rounded-full flex-shrink-0" />
                        <span className="text-gray-700 font-open-sans text-sm">
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <Button 
                    asChild
                    className="w-full bg-gray-900 hover:bg-gray-800 text-white font-montserrat font-semibold transition-all duration-300 group"
                  >
                    <Link href={service.href} className="flex items-center justify-center space-x-2">
                      <span>Learn More</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                    </Link>
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-16"
        >
          <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 font-montserrat mb-4">
            Ready to Transform Your Space?
          </h3>
          <p className="text-gray-600 font-open-sans mb-8 max-w-2xl mx-auto">
            Get started with a free consultation and estimate. We'll discuss your vision, 
            budget, and timeline to create the perfect remodeling plan for your home.
          </p>
          <Button 
            asChild
            size="lg"
            className="bg-gray-900 hover:bg-gray-800 text-white font-montserrat font-semibold px-8 py-4 transition-all duration-300 transform hover:scale-105"
          >
            <Link href="/estimate" className="flex items-center space-x-2">
              <span>Get Your Free Estimate</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
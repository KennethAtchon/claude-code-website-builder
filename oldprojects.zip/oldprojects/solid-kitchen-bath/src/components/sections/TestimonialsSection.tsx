"use client";
import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    location: "Bothell, WA",
    projectType: "Kitchen Remodel",
    rating: 5,
    text: "Solid Kitchen & Bath exceeded our expectations in every way. Their team was professional, communicative, and delivered exceptional quality. Our new kitchen is absolutely stunning and the project was completed exactly on schedule.",
    date: "2 weeks ago"
  },
  {
    id: 2,
    name: "Michael Chen",
    location: "Bellevue, WA", 
    projectType: "Bathroom Renovation",
    rating: 5,
    text: "From the initial consultation to the final walkthrough, the experience was seamless. The attention to detail and craftsmanship is evident in every aspect of our new master bathroom. Highly recommend!",
    date: "1 month ago"
  },
  {
    id: 3,
    name: "Lisa Rodriguez",
    location: "Snohomish, WA",
    projectType: "Kitchen & Bath Remodel", 
    rating: 5,
    text: "We couldn't be happier with our kitchen and bathroom remodel. The team was respectful of our home, stayed within budget, and the results are better than we ever imagined. The one-year warranty gives us peace of mind.",
    date: "3 weeks ago"
  },
  {
    id: 4,
    name: "David Thompson",
    location: "Kirkland, WA",
    projectType: "Kitchen Renovation",
    rating: 5,
    text: "Outstanding work from start to finish. The project manager kept us informed every step of the way, and the quality of workmanship is top-notch. Our friends can't believe the transformation!",
    date: "1 week ago"
  },
  {
    id: 5,
    name: "Jennifer Wilson",
    location: "Woodinville, WA",
    projectType: "Bathroom Remodel",
    rating: 5,
    text: "Professional, reliable, and skilled craftsmen. They transformed our outdated bathroom into a beautiful, modern space. The project was completed on time and the cleanup was thorough. Excellent experience overall.",
    date: "2 months ago"
  },
  {
    id: 6,
    name: "Robert Kim",
    location: "Redmond, WA",
    projectType: "Kitchen Remodel",
    rating: 5,
    text: "The team's expertise and dedication to quality is remarkable. They helped us navigate design decisions and delivered a kitchen that perfectly fits our lifestyle. The communication throughout the process was excellent.",
    date: "3 weeks ago"
  }
];

export function TestimonialsSection() {
  return (
    <section className="py-16 lg:py-24 bg-white">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          {/* Star Rating */}
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="flex items-center space-x-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
            <span className="text-gray-600 font-montserrat text-lg font-medium">
              Rated 5/5 based on 99 reviews
            </span>
          </div>

          <h2 className="text-3xl lg:text-4xl xl:text-5xl font-bold text-gray-900 font-montserrat mb-6">
            What Our Customers Say
          </h2>
          <p className="text-lg lg:text-xl text-gray-600 font-open-sans max-w-3xl mx-auto leading-relaxed">
            Don't just take our word for it. Here's what homeowners across King and Snohomish Counties 
            are saying about their remodeling experience with Solid Kitchen & Bath.
          </p>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-gray-50 rounded-lg p-6 relative"
            >
              {/* Quote Icon */}
              <div className="absolute top-4 right-4">
                <Quote className="w-8 h-8 text-gray-300" />
              </div>

              {/* Star Rating */}
              <div className="flex items-center space-x-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>

              {/* Testimonial Text */}
              <p className="text-gray-700 font-open-sans leading-relaxed mb-6">
                "{testimonial.text}"
              </p>

              {/* Customer Info */}
              <div className="border-t border-gray-200 pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-gray-900 font-montserrat">
                      {testimonial.name}
                    </h4>
                    <p className="text-sm text-gray-600 font-open-sans">
                      {testimonial.location}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900 font-montserrat">
                      {testimonial.projectType}
                    </p>
                    <p className="text-xs text-gray-500 font-open-sans">
                      {testimonial.date}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16"
        >
          <div className="bg-gray-900 rounded-lg p-8 lg:p-12 text-white">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-3xl lg:text-4xl font-bold font-montserrat mb-2">
                  99+
                </div>
                <p className="text-gray-300 font-open-sans">
                  Satisfied Customers
                </p>
              </div>
              <div>
                <div className="text-3xl lg:text-4xl font-bold font-montserrat mb-2">
                  5.0
                </div>
                <p className="text-gray-300 font-open-sans">
                  Average Rating
                </p>
              </div>
              <div>
                <div className="text-3xl lg:text-4xl font-bold font-montserrat mb-2">
                  100%
                </div>
                <p className="text-gray-300 font-open-sans">
                  Completion Rate
                </p>
              </div>
              <div>
                <div className="text-3xl lg:text-4xl font-bold font-montserrat mb-2">
                  1 Year
                </div>
                <p className="text-gray-300 font-open-sans">
                  Warranty Included
                </p>
              </div>
            </div>
            
            <div className="text-center mt-8">
              <h3 className="text-2xl lg:text-3xl font-bold font-montserrat mb-4">
                Join Our Growing List of Happy Customers
              </h3>
              <p className="text-gray-300 font-open-sans max-w-2xl mx-auto">
                Experience the difference that quality craftsmanship, clear communication, 
                and exceptional service can make in your next remodeling project.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
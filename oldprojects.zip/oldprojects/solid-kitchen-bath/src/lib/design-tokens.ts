export const designTokens = {
  colors: {
    primary: "#1f2122", // Dark charcoal text
    secondary: "#ffffff", // White
    background: "#ffffff", // White background
    gray: {
      50: "#f9fafb",
      100: "#f3f4f6", 
      200: "#e5e7eb",
      300: "#d1d5db",
      400: "#9ca3af",
      500: "#6b7280",
      600: "#4b5563",
      700: "#374151",
      800: "#1f2937",
      900: "#111827",
    },
    accent: {
      blue: "#3b82f6",
      yellow: "#fbbf24", // Star rating color
      green: "#10b981",
    },
    text: {
      primary: "#1f2122",
      secondary: "#6b7280",
      light: "#9ca3af",
    }
  },
  fonts: {
    primary: "Montserrat, sans-serif",
    secondary: "PT Serif, serif", 
    body: "Open Sans, sans-serif",
    alt: "Lato, sans-serif",
  },
  spacing: {
    xs: "4px",
    sm: "8px", 
    md: "16px",
    lg: "24px",
    xl: "32px",
    "2xl": "48px",
    "3xl": "64px",
    section: "80px", // Section padding
    container: "1200px", // Max container width
  },
  borderRadius: {
    sm: "4px",
    md: "8px", 
    lg: "12px",
    xl: "16px",
    full: "9999px",
  },
  fontSize: {
    xs: "12px",
    sm: "14px", 
    base: "16px",
    lg: "18px",
    xl: "20px",
    "2xl": "24px",
    "3xl": "30px",
    "4xl": "36px",
    "5xl": "48px",
    "6xl": "60px",
    hero: "72px",
  },
  fontWeight: {
    light: "300",
    normal: "400", 
    medium: "500",
    semibold: "600",
    bold: "700",
    extrabold: "800",
    black: "900",
  },
  lineHeight: {
    tight: "1.2",
    normal: "1.5", 
    relaxed: "1.75",
  },
  shadows: {
    sm: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
    md: "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
    lg: "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)",
    xl: "0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)",
  }
};